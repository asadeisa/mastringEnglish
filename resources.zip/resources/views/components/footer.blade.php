<div class="pt-2">
    <footer class="mt-4">
        <div class="container">
          <div class="row">
            <div class="col-lg-3">
              <div class="about footer-item">
                <div class="logo">
                  <a href="#"><img src="{{ asset('/images/logo/log.jpg') }}" alt="Smart Learn"></a>
                </div>
                <a href="#">info@company.com</a>
                <ul>
                  <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                  <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                  <li><a href="#"><i class="fa fa-behance"></i></a></li>
                  <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                </ul>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="services footer-item">
                <h4>Services</h4>
                <ul>
                  <li><a href="#">chat platform </a></li>
                  <li><a href="#">learn with expret teacher</a></li>
                  <li><a href="#">Social Media Managment</a></li>
                  <li><a href="#">AI tolles to help you </a></li>
                </ul>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="community footer-item">
                <h4>Community</h4>
                <ul>
                  <li><a href="#">E lrearning </a></li>
                  <li><a href="#">All pepoel around word</a></li>
                  <li><a href="#">teacher form defernt cultuer</a></li>
                </ul>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="subscribe-newsletters footer-item">
                <h4>Subscribe Newsletters</h4>
                <p>Get our latest news and ideas to your inbox</p>
                <form action="#" method="get">
                  <input type="text" name="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Your Email" required="">
                  <button type="submit" id="form-submit" class="main-button "></button>
                </form>
              </div>
            </div>
            <div class="col-lg-12">
              <div class="copyright">
                <p>Copyright © 2021 Smart Leran
                <br>
                Designed by <a rel="nofollow" href="#" title="free CSS templates">asad eisa</a>
              </p>
              </div>
            </div>
    
          </div>
        </div>
      </footer>
    
    
</div>