<div class="icon icon-shape  shadow text-center border-radius-md  ">
    <i class="fa-solid fa-user"></i>
  </div>