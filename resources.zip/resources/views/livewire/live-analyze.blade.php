<div>

  
   <div
   x-data="{
    
    'sentanses' : @js($allsentenses),
  

   }"
   >



    <div id="sentanses" class="d-none"  x-text="sentanses"> </div>
    <div class="show-user-error">

    </div>
   </div>
</div>
</div>
