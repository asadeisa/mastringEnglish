@extends('admin.short-cat')

@section('drop-data')

    @livewire("admin-teacher")

@endsection