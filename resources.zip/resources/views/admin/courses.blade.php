@extends('admin.short-cat')

@section('drop-data')

    @livewire("admin-courses")

@endsection