@extends('admin.short-cat')

@section('drop-data')

@livewire("main-test")

  @endsection