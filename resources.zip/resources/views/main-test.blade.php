@extends("layout.homelayout")
@section('home')
<style>
  #sidenav-main{
    display:none;
  }
</style>
@livewire("level-decated")

@endsection